# AdNull - YouTube Ad Blocker

## 🎯 Overview

**AdNull** is a clean, modular YouTube ad blocker Chrome extension with organized code structure, proper error handling, and a modern UI. The extension automatically skips YouTube ads while maintaining video functionality and compatibility.

## 🏗️ Project Structure

```
AdNull/
├── src/                    # 🚀 Main Extension (Modular Architecture)
│   ├── manifest.json       # Extension configuration
│   ├── content.js          # Main orchestrator
│   ├── modules/            # Core functionality modules
│   │   ├── config.js       # Configuration & constants
│   │   ├── logger.js       # Logging system
│   │   ├── storage.js      # Chrome storage wrapper
│   │   └── adSkipper.js    # Ad detection & skipping
│   ├── popup/              # Modern UI
│   │   ├── popup.html      # Clean layout
│   │   ├── popup.css       # Modern styling
│   │   └── popup.js        # Popup logic
│   └── icons/              # Extension icons
├── docs/                   # 📚 Documentation
│   ├── README.md           # Documentation index
│   ├── installation.md    # Installation guide
│   ├── user-guide.md      # User manual
│   ├── architecture.md    # Technical architecture
│   ├── api-reference.md   # API documentation
│   ├── troubleshooting.md # Troubleshooting guide
│   └── development.md     # Development guide
├── launch-modular.ps1      # 🚀 Extension launcher
├── README-MODULAR.md       # 📖 Modular architecture guide
├── MODULAR-SUMMARY.md      # 📊 Refactoring summary
└── README.md               # This file
```

## ✨ Features

### Core Functionality
- ✅ **Auto-skip ads** with configurable delay (instant to 2 seconds)
- ✅ **Smart ad detection** using multiple selectors
- ✅ **Arabic language support** (تخطي، تخطى، تجاوز) - NEW in v1.0.2
- ✅ **Multilingual support** (10+ languages including Arabic, Spanish, French, German, etc.)
- ✅ **Configurable logging** (ERROR, WARN, INFO, DEBUG levels)
- ✅ **Persistent settings** with Chrome storage
- ✅ **Error handling** throughout all modules

### User Interface
- ✅ **Modern popup design** with gradient header and animations
- ✅ **Toggle controls** for all settings with real-time feedback
- ✅ **Status indicators** with color coding
- ✅ **Test functionality** built into popup
- ✅ **Responsive design** that works on all screen sizes

### Developer Features
- ✅ **Modular architecture** with 6 focused modules
- ✅ **Comprehensive logging** for debugging
- ✅ **Global test functions** accessible via console
- ✅ **Clean separation of concerns**
- ✅ **Professional code organization**

## 🚀 Quick Start

### 1. Launch the Extension
```powershell
powershell -ExecutionPolicy Bypass -File "launch-modular.ps1"
```

### 2. Verify Installation
- ✅ Chrome opens with extension loaded
- ✅ Extension icon appears in toolbar
- ✅ Console shows: `[AdNull] Initializing extension`
- ✅ YouTube videos play normally

### 3. Test the Popup
- Click the extension icon
- Modern popup opens with gradient header
- Toggle settings and see real-time status updates
- Use the "Test Skip" button to manually test functionality

## 🧪 Testing & Debugging

### Console Commands
```javascript
// Test skip function
window.adnullSkipAds()

// Check extension status
window.adnullStatus()

// Get current settings
window.adnullSettings()

// Toggle extension on/off
window.adnullToggle()

// Enhanced debugging
window.adnullDebug()

// Test Arabic language support
window.adnullTestArabic()

// Access all modules for debugging
window.AdNull.Config     // Configuration
window.AdNull.Logger     // Logging system
window.AdNull.Storage    // Storage operations
window.AdNull.Skipper    // Ad skipper
```

## ⚙️ Configuration

### Default Settings
```javascript
{
  enabled: true,        // Extension enabled
  autoSkip: true,       // Auto-skip ads
  skipDelay: 1000      // 1 second delay
}
```

### Logging Levels
Change `CURRENT_LOG_LEVEL` in `src/modules/config.js`:
- `0` - ERROR only (production)
- `1` - ERROR + WARN
- `2` - ERROR + WARN + INFO (default)
- `3` - ERROR + WARN + INFO + DEBUG (development)

## 📚 Documentation

| Document | Description |
|----------|-------------|
| [README-MODULAR.md](README-MODULAR.md) | Complete modular architecture guide |
| [MODULAR-SUMMARY.md](MODULAR-SUMMARY.md) | Refactoring summary and improvements |
| [AD-TROUBLESHOOTING.md](AD-TROUBLESHOOTING.md) | Comprehensive troubleshooting guide |
| [ARABIC-SUPPORT.md](ARABIC-SUPPORT.md) | Arabic language support guide |
| [docs/](docs/) | Comprehensive documentation folder |
| [docs/installation.md](docs/installation.md) | Installation instructions |
| [docs/user-guide.md](docs/user-guide.md) | User manual and features |
| [docs/architecture.md](docs/architecture.md) | Technical architecture |
| [docs/troubleshooting.md](docs/troubleshooting.md) | Common issues and fixes |

## 🛡️ Safety & Compatibility

### Conservative Approach
- **Minimal permissions** (only activeTab, storage, scripting)
- **No background script** to reduce resource usage
- **Safe selectors** that won't break YouTube
- **Graceful fallbacks** when Chrome APIs unavailable
- **Error boundaries** to prevent crashes

### YouTube Compatibility
- **Non-intrusive** - Only clicks skip buttons
- **No CSS injection** that could hide content
- **No DOM manipulation** beyond button clicking
- **Respects YouTube's structure** and updates

## 🏗️ Architecture Benefits

### Modular Design
- ✅ **Single responsibility** - Each module has one clear purpose
- ✅ **Easy maintenance** - Changes isolated to specific modules
- ✅ **Simple testing** - Test modules independently
- ✅ **Extensible** - Easy to add new features

### Code Quality
- ✅ **Comprehensive error handling** with try-catch blocks
- ✅ **Professional logging** with configurable levels
- ✅ **Centralized configuration** in one place
- ✅ **JSDoc documentation** for all functions
- ✅ **Consistent code style** throughout

## 📈 Performance

- ✅ **Efficient loading** - Modules load only when needed
- ✅ **Memory management** - Proper cleanup and disposal
- ✅ **Fast initialization** - Optimized startup sequence
- ✅ **Resource efficiency** - Minimal background usage

## 🎉 What's New

This extension has been **completely refactored** from a basic single-file script into a professional, modular Chrome extension:

- 🏗️ **Clean architecture** with 6 focused modules
- 🎨 **Modern UI** with gradient design and animations
- 🛡️ **Robust error handling** throughout all components
- 📊 **Professional logging** with configurable levels
- ⚙️ **Centralized configuration** for easy maintenance
- 🧪 **Built-in testing** and debugging capabilities
- 📁 **Organized codebase** with no unused files
- 🌍 **Arabic language support** (v1.0.2) - تخطي، تخطى، تجاوز
- 🗣️ **Multilingual support** for 10+ languages

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

**The AdNull extension is now production-ready, maintainable, and extensible!** 🚀

*Use `launch-modular.ps1` to test the extension.*
